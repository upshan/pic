package util.gson;

/**
 * 简单的ID, Name对象，用于前端显示。
 */
public class IdNameObject {

    public String id;

    public String name;
}

package util.common;

public enum Weeks {
    SUNDAY, // 礼拜天
    MONDAY, // 礼拜一
    TUESDAY, //礼拜二
    WEDNESDAY, //礼拜三
    THURSDAY, // 礼拜四
    FRIDAY, // 礼拜五
    SATURDAY // 礼拜六
}
